#include "ros/ros.h"
#include "OceanTechSideSonarAPI.h"
#include "OceanTechSSSHeaderAPI.h"
#include "string.h"
#include "iostream"
#include "cstring"
#include "nav_msgs/Odometry.h"
#include "sensor_msgs/Image.h"
#include "sensor_msgs/image_encodings.h"
#include "tf/transform_listener.h"
#include "sidescansonar/SonarConfig.h"
#include "sidescansonar/SonarWork.h"
#include "sidescansonar/Gps.h"
#include "sidescansonar/LowFreqFrameDataHeader.h"
#include "sidescansonar/HighFreqFrameDataHeader.h"

int	  g_ImageHeight;
int	  g_ImageWidth;


class Sidescansonar
{
	protected:
		ros::NodeHandle nh;
		ros::ServiceServer sonar_work_server;
		ros::ServiceServer sonar_config_server;
		ros::Subscriber gps_sub_;
		ros::Subscriber odom_sub_;
		ros::Publisher highfreq_data_pub_ = nh.advertise<sidescansonar::LowFreqFrameDataHeader>("highfreq_data_header",1);
		ros::Publisher lowfreq_data_pub_ = nh.advertise<sidescansonar::LowFreqFrameDataHeader>("lowfreq_data_header",1);
		ros::Publisher highfreq_image_pub_= nh.advertise<sensor_msgs::Image>("highfreq_image_data",1);;
		ros::Publisher lowfreq_image_pub_ = nh.advertise<sensor_msgs::Image>("lowfreq_image_data",1);;
		ConfigSonarParam m_LowFreqSonarParam;
		ConfigSonarParam m_HighFreqSonarParam;
		NavPositionData m_GpsData;
		AttitudeSensorData m_Odomdata;
		bool configSrv(sidescansonar::SonarConfig::Request &req,
							sidescansonar::SonarConfig::Response& res);
		bool workSrv(sidescansonar::SonarWork::Request &req,
							sidescansonar::SonarWork::Response &res);
		void  doGps(const sidescansonar::Gps::ConstPtr &gps);
		void callback_odom(const nav_msgs::Odometry::ConstPtr& odom);
		
		void run();

	private:
		
	public:
		SonarFrameDataHeader m_LowFreqCurrentSonarFrameDataHeader;
		SonarFrameDataHeader m_HighFreqCurrentSonarFrameDataHeader;
		unsigned short* m_pLowFreqRawData;
		unsigned int m_nCurrentLowFreqRawDataBufSize;

		unsigned short* m_pHighFreqRawData;
		unsigned int m_nCurrentHighFreqRawDataBufSize;

		unsigned char* m_pLowFreqImageData;
		unsigned char* m_pHighFreqImageData;
		SonarFrameDataHeader* GetLowFreqFrameDataHeader();
		SonarFrameDataHeader* GetHighFreqFrameDataHeader();

		unsigned char* GetLowFreqImageData();
		unsigned char* GetHighFreqImageData();

		void GetSonarRawData(void* pLowFreqFrameDataHeader, unsigned short* pLowFreqRawData,
			void* pHighFreqFrameDataHeader, unsigned short* pHighFreqRawData);

		void GetSonarImageData(void* pLowFreqFrameDataHeader, unsigned char* pLowFreqImageData,
			void* pHighFreqFrameDataHeader, unsigned char* pHighFreqImageData);
	public:
		Sidescansonar();
		~Sidescansonar();

		void sss_init();
};

Sidescansonar::Sidescansonar() :nh("~")
{
	memset(&m_LowFreqCurrentSonarFrameDataHeader, 0, sizeof(SonarFrameDataHeader));
	memset(&m_HighFreqCurrentSonarFrameDataHeader, 0, sizeof(SonarFrameDataHeader));

	m_nCurrentLowFreqRawDataBufSize = 18000 * sizeof(unsigned short);
	m_pLowFreqRawData = new unsigned short[m_nCurrentLowFreqRawDataBufSize];

	m_nCurrentHighFreqRawDataBufSize = 18000 * sizeof(unsigned short);
	m_pHighFreqRawData = new unsigned short[m_nCurrentHighFreqRawDataBufSize];

	unsigned int nImageSize = g_ImageWidth * g_ImageHeight * 3;
	m_pLowFreqImageData = new unsigned char[nImageSize];
	memset(m_pLowFreqImageData, 0, nImageSize);

	m_pHighFreqImageData = new unsigned char[nImageSize];
	memset(m_pHighFreqImageData, 0, nImageSize);
}

Sidescansonar::~Sidescansonar()
{

}



bool g_StartSonarWorkState;
bool g_StartStopWorkState;
bool g_SonarIsProcessingState;
void  g_StartSonarWorkCallback(bool bState)
{
	if(g_StartSonarWorkState !=bState){
	g_StartSonarWorkState = bState;
    //ROS_INFO("workstate--%d",bState);
	}
}
void  g_StartStopWorkCallBack(bool bState)
{
	if(g_StartStopWorkState!=bState){
	g_StartStopWorkState = bState;
    // ROS_INFO("stopstate--%d",bState);
	}
}

void  g_SonarIsProcessingCallBack(bool bState)
{	
	if(g_SonarIsProcessingState!=bState){
	g_SonarIsProcessingState = bState;
    ROS_INFO("on working--%d",bState);
	}
}

void  g_OutPutMessage(int nMessageType, const char* strMessage)
{
	// CMainFrame *pMainWnd;
	// pMainWnd = (CMainFrame*)AfxGetApp()->GetMainWnd();
	// if (pMainWnd != NULL)
	// {
	// 	pMainWnd->OutPutMessage(nMessageType, strMessage);
	// }
    ROS_INFO("%s",strMessage);
}

void  g_GetSonarRawData(void* pLowFreqFrameDataHeader, unsigned short* pLowFreqRawData,
							void* pHighFreqFrameDataHeader, unsigned short* pHighFreqRawData){
						Sidescansonar ss;
						ss.GetSonarRawData(pLowFreqFrameDataHeader, pLowFreqRawData,
						  pHighFreqFrameDataHeader, pHighFreqRawData);
							}

void Sidescansonar:: GetSonarRawData(void* pLowFreqFrameDataHeader, unsigned short* pLowFreqRawData,
	void* pHighFreqFrameDataHeader, unsigned short* pHighFreqRawData)
{
	SonarFrameDataHeader* pLowFreqHeader = (SonarFrameDataHeader*)pLowFreqFrameDataHeader;
	if (pLowFreqHeader != NULL && pLowFreqHeader->DataType == 0)
	{
		memcpy(&m_LowFreqCurrentSonarFrameDataHeader, pLowFreqFrameDataHeader, sizeof(SonarFrameDataHeader));
		ROS_INFO("lowdataheader");
		sidescansonar::LowFreqFrameDataHeader lowfreq_data;
		lowfreq_data.PingNumber= m_LowFreqCurrentSonarFrameDataHeader.PingNumber;
		// ROS_INFO("PINGnum:%d",lowfreq_data.PingNumber);
		lowfreq_data.NumSamples= m_LowFreqCurrentSonarFrameDataHeader.NumSamples;
		lowfreq_data.Year= m_LowFreqCurrentSonarFrameDataHeader.Year;
		lowfreq_data.Month= m_LowFreqCurrentSonarFrameDataHeader.Month;
		lowfreq_data.Day= m_LowFreqCurrentSonarFrameDataHeader.Day;
		lowfreq_data.Hour= m_LowFreqCurrentSonarFrameDataHeader.Hour;
		lowfreq_data.Minute= m_LowFreqCurrentSonarFrameDataHeader.Minute;
		lowfreq_data.Second= m_LowFreqCurrentSonarFrameDataHeader.Second;
		lowfreq_data.hSecond= m_LowFreqCurrentSonarFrameDataHeader.hSecond;
		lowfreq_data.Heading= m_LowFreqCurrentSonarFrameDataHeader.Heading;
		lowfreq_data.Pitch= m_LowFreqCurrentSonarFrameDataHeader.Pitch;
		lowfreq_data.Roll= m_LowFreqCurrentSonarFrameDataHeader.Roll;
		lowfreq_data.Depth= m_LowFreqCurrentSonarFrameDataHeader.Depth;
		lowfreq_data.Altitude= m_LowFreqCurrentSonarFrameDataHeader.Altitude;
		lowfreq_data.SoundSpeed= m_LowFreqCurrentSonarFrameDataHeader.SoundSpeed;
		lowfreq_data.Speed= m_LowFreqCurrentSonarFrameDataHeader.Speed;
		lowfreq_data.GPSHeading= m_LowFreqCurrentSonarFrameDataHeader.GPSHeading;
		lowfreq_data.Lat= m_LowFreqCurrentSonarFrameDataHeader.Lat;
		lowfreq_data.Lon= m_LowFreqCurrentSonarFrameDataHeader.Lon;
		lowfreq_data.DegreesTrue= m_LowFreqCurrentSonarFrameDataHeader.DegreesTrue;
		lowfreq_data.Pressure= m_LowFreqCurrentSonarFrameDataHeader.Pressure;
		lowfreq_data.TowfishSpeedType= m_LowFreqCurrentSonarFrameDataHeader.TowfishSpeedType;
		lowfreq_data.ManualSpeed= m_LowFreqCurrentSonarFrameDataHeader.ManualSpeed;
		lowfreq_data.BeamDistance= m_LowFreqCurrentSonarFrameDataHeader.BeamDistance;
		lowfreq_data.PostionFixYear= m_LowFreqCurrentSonarFrameDataHeader.PostionFixYear;
		lowfreq_data.PostionFixMonth= m_LowFreqCurrentSonarFrameDataHeader.PostionFixMonth;
		lowfreq_data.PostionFixDay= m_LowFreqCurrentSonarFrameDataHeader.PostionFixDay;
		lowfreq_data.PostionFixHour= m_LowFreqCurrentSonarFrameDataHeader.PostionFixHour;
		lowfreq_data.PostionFixMinute= m_LowFreqCurrentSonarFrameDataHeader.PostionFixMinute;
		lowfreq_data.PostionFixSecond= m_LowFreqCurrentSonarFrameDataHeader.PostionFixSecond;
		lowfreq_data.PostionFixhSecond= m_LowFreqCurrentSonarFrameDataHeader.PostionFixhSecond;
		lowfreq_data.SynMode= m_LowFreqCurrentSonarFrameDataHeader.SynMode;
		lowfreq_data.Frequency= m_LowFreqCurrentSonarFrameDataHeader.Frequency;
	 	lowfreq_data.WorkRange= m_LowFreqCurrentSonarFrameDataHeader.WorkRange;
		
	 	lowfreq_data.Absorb= m_LowFreqCurrentSonarFrameDataHeader.Absorb;
	 	lowfreq_data.Gain= m_LowFreqCurrentSonarFrameDataHeader.Gain;
		// ROS_INFO("lowfreq_workrange:%d,abosrb:%d,Gain:%d",lowfreq_data.WorkRange,m_LowFreqCurrentSonarFrameDataHeader.Absorb,lowfreq_data.Gain);
		lowfreq_data.TxPulseBandWidth= m_LowFreqCurrentSonarFrameDataHeader.TxPulseBandWidth;
		lowfreq_data.TxPulseType= m_LowFreqCurrentSonarFrameDataHeader.TxPulseType;
		lowfreq_data.BeamNumber= m_LowFreqCurrentSonarFrameDataHeader.BeamNumber;
		lowfreq_data.CableOut= m_LowFreqCurrentSonarFrameDataHeader.CableOut;
		lowfreq_data.NavAntennaToTowpointShipHeading= m_LowFreqCurrentSonarFrameDataHeader.NavAntennaToTowpointShipHeading;
		lowfreq_data.NavAntennaToTowpointStarboard= m_LowFreqCurrentSonarFrameDataHeader.NavAntennaToTowpointStarboard;
		lowfreq_data.TowpointToSealevelHeight= m_LowFreqCurrentSonarFrameDataHeader.TowpointToSealevelHeight;
		lowfreq_data.TowfishDepthType= m_LowFreqCurrentSonarFrameDataHeader.TowfishDepthType;
		lowfreq_data.ManaulDepth= m_LowFreqCurrentSonarFrameDataHeader.ManaulDepth;
		lowfreq_data.DataType= m_LowFreqCurrentSonarFrameDataHeader.DataType;
		lowfreq_data.ImageWidth= m_LowFreqCurrentSonarFrameDataHeader.ImageWidth;
		lowfreq_data.ImageHeight= m_LowFreqCurrentSonarFrameDataHeader.ImageHeight;
	    lowfreq_data_pub_.publish(lowfreq_data);
		if (pLowFreqRawData != NULL)
		{
			unsigned int n0DataSize = m_LowFreqCurrentSonarFrameDataHeader.NumSamples * m_LowFreqCurrentSonarFrameDataHeader.BeamNumber * sizeof(unsigned short)* 2;
			// ROS_INFO("nunsamples:%d,beamnumber:%ddatasize:%d",m_LowFreqCurrentSonarFrameDataHeader.NumSamples,m_LowFreqCurrentSonarFrameDataHeader.BeamNumber,n0DataSize);
			if (n0DataSize > m_nCurrentLowFreqRawDataBufSize)
			{
				if (m_pLowFreqRawData != NULL)
					delete[]m_pLowFreqRawData;

				m_pLowFreqRawData = new unsigned short[n0DataSize];
				m_nCurrentLowFreqRawDataBufSize = n0DataSize;
			}

			// memcpy(m_pLowFreqRawData, pLowFreqRawData, n0DataSize);
		}

	}

	//高频数据
	SonarFrameDataHeader* pHighFreqHeader = (SonarFrameDataHeader*)pHighFreqFrameDataHeader;
	if (pHighFreqHeader != NULL && pHighFreqHeader->DataType == 0)
	{
		memcpy(&m_HighFreqCurrentSonarFrameDataHeader, pHighFreqFrameDataHeader, sizeof(SonarFrameDataHeader));
		sidescansonar::HighFreqFrameDataHeader highfreq_data;
		ROS_INFO("highdataheader");
		highfreq_data.PingNumber= m_HighFreqCurrentSonarFrameDataHeader.PingNumber;
		highfreq_data.NumSamples= m_HighFreqCurrentSonarFrameDataHeader.NumSamples;
		highfreq_data.Year= m_HighFreqCurrentSonarFrameDataHeader.Year;
		highfreq_data.Month= m_HighFreqCurrentSonarFrameDataHeader.Month;
		highfreq_data.Day= m_HighFreqCurrentSonarFrameDataHeader.Day;
		highfreq_data.Hour= m_HighFreqCurrentSonarFrameDataHeader.Hour;
		highfreq_data.Minute= m_HighFreqCurrentSonarFrameDataHeader.Minute;
		highfreq_data.Second= m_HighFreqCurrentSonarFrameDataHeader.Second;
		highfreq_data.hSecond= m_HighFreqCurrentSonarFrameDataHeader.hSecond;
		highfreq_data.Heading= m_HighFreqCurrentSonarFrameDataHeader.Heading;
		highfreq_data.Pitch= m_HighFreqCurrentSonarFrameDataHeader.Pitch;
		highfreq_data.Roll= m_HighFreqCurrentSonarFrameDataHeader.Roll;
		highfreq_data.Depth= m_HighFreqCurrentSonarFrameDataHeader.Depth;
		highfreq_data.Altitude= m_HighFreqCurrentSonarFrameDataHeader.Altitude;
		highfreq_data.SoundSpeed= m_HighFreqCurrentSonarFrameDataHeader.SoundSpeed;
		highfreq_data.Speed= m_HighFreqCurrentSonarFrameDataHeader.Speed;
		highfreq_data.GPSHeading= m_HighFreqCurrentSonarFrameDataHeader.GPSHeading;
		highfreq_data.Lat= m_HighFreqCurrentSonarFrameDataHeader.Lat;
		highfreq_data.Lon= m_HighFreqCurrentSonarFrameDataHeader.Lon;
		highfreq_data.DegreesTrue= m_HighFreqCurrentSonarFrameDataHeader.DegreesTrue;
		highfreq_data.Pressure= m_HighFreqCurrentSonarFrameDataHeader.Pressure;
		highfreq_data.TowfishSpeedType= m_HighFreqCurrentSonarFrameDataHeader.TowfishSpeedType;
		highfreq_data.ManualSpeed= m_HighFreqCurrentSonarFrameDataHeader.ManualSpeed;
		highfreq_data.BeamDistance= m_HighFreqCurrentSonarFrameDataHeader.BeamDistance;
		highfreq_data.PostionFixYear= m_HighFreqCurrentSonarFrameDataHeader.PostionFixYear;
		highfreq_data.PostionFixMonth= m_HighFreqCurrentSonarFrameDataHeader.PostionFixMonth;
		highfreq_data.PostionFixDay= m_HighFreqCurrentSonarFrameDataHeader.PostionFixDay;
		highfreq_data.PostionFixHour= m_HighFreqCurrentSonarFrameDataHeader.PostionFixHour;
		highfreq_data.PostionFixMinute= m_HighFreqCurrentSonarFrameDataHeader.PostionFixMinute;
		highfreq_data.PostionFixSecond= m_HighFreqCurrentSonarFrameDataHeader.PostionFixSecond;
		highfreq_data.PostionFixhSecond= m_HighFreqCurrentSonarFrameDataHeader.PostionFixhSecond;
		highfreq_data.SynMode= m_HighFreqCurrentSonarFrameDataHeader.SynMode;
		highfreq_data.Frequency= m_HighFreqCurrentSonarFrameDataHeader.Frequency;
		highfreq_data.WorkRange= m_HighFreqCurrentSonarFrameDataHeader.WorkRange;
		highfreq_data.Absorb= m_HighFreqCurrentSonarFrameDataHeader.Absorb;
		// ROS_INFO("HIgh Absorb:%d--%d",m_HighFreqCurrentSonarFrameDataHeader.Absorb,highfreq_data.Absorb);
		highfreq_data.Gain= m_HighFreqCurrentSonarFrameDataHeader.Gain;
		highfreq_data.TxPulseBandWidth= m_HighFreqCurrentSonarFrameDataHeader.TxPulseBandWidth;
		highfreq_data.TxPulseType= m_HighFreqCurrentSonarFrameDataHeader.TxPulseType;
		highfreq_data.BeamNumber= m_HighFreqCurrentSonarFrameDataHeader.BeamNumber;
		highfreq_data.CableOut= m_HighFreqCurrentSonarFrameDataHeader.CableOut;
		highfreq_data.NavAntennaToTowpointShipHeading= m_HighFreqCurrentSonarFrameDataHeader.NavAntennaToTowpointShipHeading;
		highfreq_data.NavAntennaToTowpointStarboard= m_HighFreqCurrentSonarFrameDataHeader.NavAntennaToTowpointStarboard;
		highfreq_data.TowpointToSealevelHeight= m_HighFreqCurrentSonarFrameDataHeader.TowpointToSealevelHeight;
		highfreq_data.TowfishDepthType= m_HighFreqCurrentSonarFrameDataHeader.TowfishDepthType;
		highfreq_data.ManaulDepth= m_HighFreqCurrentSonarFrameDataHeader.ManaulDepth;
		highfreq_data.DataType= m_HighFreqCurrentSonarFrameDataHeader.DataType;
		highfreq_data.ImageWidth= m_HighFreqCurrentSonarFrameDataHeader.ImageWidth;
		highfreq_data.ImageHeight= m_HighFreqCurrentSonarFrameDataHeader.ImageHeight;
		// ROS_INFO("highdata--imagewidth:%d   imageheight:%d",m_HighFreqCurrentSonarFrameDataHeader.ImageWidth,m_HighFreqCurrentSonarFrameDataHeader.ImageHeight);
		highfreq_data_pub_.publish(highfreq_data);
		if (pHighFreqRawData != NULL)
		{
			unsigned int n1DataSize = m_HighFreqCurrentSonarFrameDataHeader.NumSamples * m_HighFreqCurrentSonarFrameDataHeader.BeamNumber * sizeof(unsigned short)* 2;
			ROS_INFO("nunsamples:%u,beamnumber:%udatasize:%u",m_HighFreqCurrentSonarFrameDataHeader.NumSamples,m_HighFreqCurrentSonarFrameDataHeader.BeamNumber,n1DataSize);
			
			if (n1DataSize > m_nCurrentHighFreqRawDataBufSize)
			{
				if (m_pHighFreqRawData != NULL)
					delete[]m_pHighFreqRawData;

				m_pHighFreqRawData = new unsigned short[n1DataSize];
				m_nCurrentHighFreqRawDataBufSize = n1DataSize;
			}

			// memcpy(m_pHighFreqRawData, pHighFreqRawData, n1DataSize);
		}
	}
	ROS_INFO("raw data done");
}

void  g_GetSonarImageData(void* pLowFreqFrameDataHeader, unsigned char* pLowFreqImageData,
	void* pHighFreqFrameDataHeader, unsigned char* pHighFreqImageData)
{
	Sidescansonar s1s;
	s1s.GetSonarImageData(pLowFreqFrameDataHeader, pLowFreqImageData,
	pHighFreqFrameDataHeader, pHighFreqImageData);
}

void Sidescansonar:: GetSonarImageData(void* pLowFreqFrameDataHeader, unsigned char* pLowFreqImageData,
	void* pHighFreqFrameDataHeader, unsigned char* pHighFreqImageData)
{
	unsigned char* pImageDataBufferTemp = new unsigned char[g_ImageWidth * g_ImageHeight * 3];

	//低频数据
	sensor_msgs::Image lowfreq_image;
	sensor_msgs::Image highfreq_image;
	SonarFrameDataHeader* pLowFreqHeader = (SonarFrameDataHeader*)pLowFreqFrameDataHeader;
	if (pLowFreqHeader != NULL && pLowFreqHeader->DataType == 1)
	{
		memcpy(&m_LowFreqCurrentSonarFrameDataHeader, pLowFreqFrameDataHeader, sizeof(SonarFrameDataHeader));

		if (pLowFreqImageData != NULL)
		{
			// memcpy(pImageDataBufferTemp, m_pLowFreqImageData, g_ImageWidth * g_ImageHeight * 3);

			unsigned int nNewImage0DataSize = m_LowFreqCurrentSonarFrameDataHeader.ImageWidth * m_LowFreqCurrentSonarFrameDataHeader.ImageHeight * 3;
			// ROS_INFO("imagewidth:%u,imageheight:%undatasize:%u",m_LowFreqCurrentSonarFrameDataHeader.ImageWidth,m_LowFreqCurrentSonarFrameDataHeader.ImageHeight,nNewImage0DataSize);
			// memcpy(m_pLowFreqImageData, pLowFreqImageData, nNewImage0DataSize);
			// memcpy(m_pLowFreqImageData + nNewImage0DataSize, pImageDataBufferTemp, g_ImageWidth * g_ImageHeight * 3 - nNewImage0DataSize);
			unsigned char * lowimagedata = (unsigned char *)malloc(nNewImage0DataSize);
			memcpy(lowimagedata, pLowFreqImageData, nNewImage0DataSize);
			lowfreq_image.width=m_LowFreqCurrentSonarFrameDataHeader.ImageWidth;
			lowfreq_image.height=m_LowFreqCurrentSonarFrameDataHeader.ImageHeight;
			lowfreq_image.step=nNewImage0DataSize;
			lowfreq_image.encoding="rgb8";
			std::vector<unsigned char>  str(lowimagedata,lowimagedata+nNewImage0DataSize);
			lowfreq_image.data=str;
			
			lowfreq_image_pub_.publish(lowfreq_image);
			free(lowimagedata);
					}
	}

	//高频数据
	SonarFrameDataHeader* pHighFreqHeader = (SonarFrameDataHeader*)pHighFreqFrameDataHeader;
	if (pHighFreqHeader != NULL && pHighFreqHeader->DataType == 1)
	{
		memcpy(&m_HighFreqCurrentSonarFrameDataHeader, pHighFreqFrameDataHeader, sizeof(SonarFrameDataHeader));

		if (pHighFreqImageData != NULL)
		{
			// m_pHighFreqImageData=(char *)malloc(5760);
			
			// memcpy(pImageDataBufferTemp, m_pHighFreqImageData, g_ImageWidth * g_ImageHeight * 3);

			unsigned int nNewImage1DataSize = m_HighFreqCurrentSonarFrameDataHeader.ImageWidth * m_HighFreqCurrentSonarFrameDataHeader.ImageHeight * 3;
			// ROS_INFO("high---imagewidth:%u,imageheight:%undatasize:%u",m_HighFreqCurrentSonarFrameDataHeader.ImageWidth,m_HighFreqCurrentSonarFrameDataHeader.ImageHeight,nNewImage1DataSize);
			
			// memcpy(m_pHighFreqImageData, pHighFreqImageData, nNewImage1DataSize);
			// memcpy(m_pHighFreqImageData + nNewImage1DataSize, pImageDataBufferTemp, g_ImageWidth * g_ImageHeight * 3 - nNewImage1DataSize);
			unsigned char * highimagedata = (unsigned char *)malloc(nNewImage1DataSize);
			memcpy(highimagedata, pHighFreqImageData, nNewImage1DataSize);
			unsigned char a=1;
			
			highfreq_image.width=m_HighFreqCurrentSonarFrameDataHeader.ImageWidth;
			highfreq_image.height=m_HighFreqCurrentSonarFrameDataHeader.ImageHeight;
			highfreq_image.step=nNewImage1DataSize;
			highfreq_image.encoding="rgb8";
			std::vector<unsigned char>  str(highimagedata,highimagedata+nNewImage1DataSize);
			highfreq_image.data=str;
			
			highfreq_image_pub_.publish(highfreq_image);
			free(highimagedata);
		}
	}

	delete[]pImageDataBufferTemp;

}



bool Sidescansonar::workSrv(sidescansonar::SonarWork::Request &req,
							sidescansonar::SonarWork::Response& res)
{
	int work_state = req.work_state;
	int enablesavedata = req.enablesavedata;
	

	if(enablesavedata==1)
	{
		EnableSaveDataOTF(true);
    	EnableSaveDataXTF(true);
	}else
	{
		EnableSaveDataOTF(false);
   		EnableSaveDataXTF(false);
	}

	if(work_state==1)
	{
		SonarStartWork();	
	}else
	{
		SonarStopWork();
	}

	res.IsOn = 1;
	return true;
}

bool Sidescansonar::configSrv(sidescansonar::SonarConfig::Request &req,
							sidescansonar::SonarConfig::Response& res)
{
	int nFreqType = req.nFreqType;
	if(nFreqType==0){
		m_LowFreqSonarParam.Frequency=req.Frequency;
		m_LowFreqSonarParam.SynMode=req.SynMode;
		m_LowFreqSonarParam.WorkRange=req.WorkRange;
		m_LowFreqSonarParam.Power=req.Power;
		m_LowFreqSonarParam.Absorb=req.Absorb;
		m_LowFreqSonarParam.Gain=req.Gain;
		m_LowFreqSonarParam.SpeedMode=req.SpeedMode;
		m_LowFreqSonarParam.SoundSpeedSonar=req.SoundSpeedSonar;
		SetSonarParams(0, &m_LowFreqSonarParam);

	}else{ 
		m_HighFreqSonarParam.Frequency=req.Frequency;
		m_HighFreqSonarParam.SynMode=req.SynMode;
		m_HighFreqSonarParam.WorkRange=req.WorkRange;
		m_HighFreqSonarParam.Power=req.Power;
		m_HighFreqSonarParam.Absorb=req.Absorb;
		m_HighFreqSonarParam.Gain=req.Gain;
		m_HighFreqSonarParam.SpeedMode=req.SpeedMode;
		m_HighFreqSonarParam.SoundSpeedSonar=req.SoundSpeedSonar;
		SetSonarParams(1, &m_HighFreqSonarParam);
	}
	return true;
	
	
}

void Sidescansonar::doGps(const sidescansonar::Gps::ConstPtr &gps){
	// m_GpsData.Year = gps.;
	// m_GpsData.Month = ;
	// m_GpsData.Day = ;
	// m_GpsData.Hour = ;
	// m_GpsData.Minute = ;
	// m_GpsData.Second = ;
	// m_GpsData.Milliseconds = ;
	m_GpsData.Speed = gps->speed;
	m_GpsData.Heading = gps->direction;
	m_GpsData.Lat = gps->latitude;
	m_GpsData.Lon = gps->longitude;
	SetNavPositonData(&m_GpsData);
}

void Sidescansonar::callback_odom(const nav_msgs::Odometry::ConstPtr& odom){
	double x, y, z;
    double roll, pitch, yaw;
    x = odom->pose.pose.position.x;
    y = odom->pose.pose.position.y;
    z = odom->pose.pose.position.z;
    tf::Quaternion quat;                                     //定义一个四元数
    tf::quaternionMsgToTF(odom->pose.pose.orientation, quat); //取出方向存储于四元数
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);
	m_Odomdata.Heading = yaw;
	m_Odomdata.Pitch = pitch;
	m_Odomdata.Roll = roll;
	SetAttitudeData(&m_Odomdata);
}

void Sidescansonar::sss_init()
{
	gps_sub_ = nh.subscribe("/Sensor/Gps",1,&Sidescansonar::doGps,this);
	odom_sub_ = nh.subscribe("odom", 1, &Sidescansonar::callback_odom, this);
	LoadOceanTechSSSAPI();
    SetSonarDataDir("/home/ubuntu/sss_data/");
    SetSonarIPAndPort("192.168.0.88",7);
	SetWorkMode(2);
    // EnableSaveDataOTF(true);
    // EnableSaveDataXTF(true);
    SetOnlySaveSonarRawData(false);
	ReverseRGBDataBit(false);// false->RGB
    Set_StartSonarWork_FuncPrt((void*)g_StartSonarWorkCallback);
	Set_StartStopWork_FuncPrt((void*)g_StartStopWorkCallBack);
	Set_SonarIsProcessingCallBack_FuncPrt((void*)g_SonarIsProcessingCallBack);
	Set_OutPutMessage_FuncPrt((void*)g_OutPutMessage);
	Set_GetSonarRawData_FuncPrt((void*)g_GetSonarRawData);
	Set_GetImageData_FuncPrt((void*) g_GetSonarImageData);

	
	sonar_work_server = nh.advertiseService("sonarwork",&Sidescansonar::workSrv,this);
	ROS_INFO("work_server start work");
	sleep(1);
	sonar_config_server = nh.advertiseService("sonarconfig",&Sidescansonar::configSrv,this);
	ROS_INFO("config_server start work");
	run();
}

void Sidescansonar::run()
{
	ros::Rate loop_rate(40);
	//SonarStartWork();//
 	while(ros::ok())
 		{
		
		ros::spinOnce();
  		loop_rate.sleep();


 		}
	if(ros::ok()){
		sss_init();
	}
}

int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");
	//ConfigSonarParam pSonarParams;
    ros::init(argc,argv,"main");
    // ROS_INFO("hello");
    // ros::start();
	Sidescansonar sss;
	
	sss.sss_init();
    
    //SonarStopWork();
    // EnableSaveDataOTF(false);
    // EnableSaveDataXTF(false);
    UnLoadOceanTechSSSAPI();
    
    return 0;
}
