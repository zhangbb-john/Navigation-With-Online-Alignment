  z->measurement(0) = msg->fluid_pressure - targetFrameTrans.getOrigin().z(); is very strange

  isDVLInitialized(false), of no use 


initial state can be adjusted in yaml
        x.setZero();
      P = initialP_;

wrong DVL angle cause diverge for a probability

right angle still diverge

q: 0 0.7 0.7 0; 1 0 0 0 
just for test usbl angle frequency and accuracy

yaml set simulation params shape, magnitude, freq , rotation speed, speed and so on;


q: 0 0.7 0.7 0; 1 0 0 0 
just for test usbl angle frequency and accuracy

seems wrong yaml;
some problems in recvim
wrong theta process covariance
sample for 1s
diverge for angle at first
# ceres
## num
new ceres::AutoDiffCostFunction<
	          ReprojectionError3D, 2, 4, 3, 3>(
	          	new ReprojectionError3D(observed_x,observed_y))
2:residual
4 param1
3 param2
3 param3
ceres::CostFunction* cost_function = ReprojectionError3D::Create(
                                    sfm_f[i].observation[j].second.x(),
                                    sfm_f[i].observation[j].second.y());

problem.AddResidualBlock(cost_function, NULL, c_rotation[l], c_translation[l], 
                        sfm_f[i].position);	 
### 2
    	residuals[0] = xp - T(observed_u);
    	residuals[1] = yp - T(observed_v);
### creat is data

## eigen 
```
CataCamera::spaceToPlane(const T* const params,
                         const T* const q, const T* const t,
                         const Eigen::Matrix<T, 3, 1>& P,
                         Eigen::Matrix<T, 2, 1>& p)
{
    T P_w[3];
    P_w[0] = T(P(0));
    P_w[1] = T(P(1));
    P_w[2] = T(P(2));

    // Convert quaternion from Eigen convention (x, y, z, w)
    // to Ceres convention (w, x, y, z)
    T q_ceres[4] = {q[3], q[0], q[1], q[2]};

    T P_c[3];
    ceres::QuaternionRotatePoint(q_ceres, P_w, P_c);

    P_c[0] += t[0];
    P_c[1] += t[1];
    P_c[2] += t[2];

    // project 3D object point to the image plane
    T xi = params[0];
    T k1 = params[1];
    T k2 = params[2];
    T p1 = params[3];
    T p2 = params[4];
    T gamma1 = params[5];
    T gamma2 = params[6];
    T alpha = T(0); //cameraParams.alpha();
    T u0 = params[7];
    T v0 = params[8];

    // Transform to model plane
    T len = sqrt(P_c[0] * P_c[0] + P_c[1] * P_c[1] + P_c[2] * P_c[2]);
    P_c[0] /= len;
    P_c[1] /= len;
    P_c[2] /= len;

    T u = P_c[0] / (P_c[2] + xi);
    T v = P_c[1] / (P_c[2] + xi);

    T rho_sqr = u * u + v * v;
    T L = T(1.0) + k1 * rho_sqr + k2 * rho_sqr * rho_sqr;
    T du = T(2.0) * p1 * u * v + p2 * (rho_sqr + T(2.0) * u * u);
    T dv = p1 * (rho_sqr + T(2.0) * v * v) + T(2.0) * p2 * u * v;

    u = L * u + du;
    v = L * v + dv;
    p(0) = gamma1 * (u + alpha * v) + u0;
    p(1) = gamma2 * v + v0;
}
```

# there is some time delay 
bag is later than imu time by 0.02s
# now we have to ignore the delay of usblangles

