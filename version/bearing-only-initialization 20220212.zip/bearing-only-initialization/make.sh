# ccache is from epel mirrors:http://mirrors.xxxx.com.cn/epel/7Server/x86_64/
clear
start_time=$(date +%s)
cd .. 
dir="$(pwd)"
rm -rf CMakeLists.txt
cd ..
rm -rf ./devel ./build
sleep 3
catkin_make -DCATKIN_WHITELIST_PACKAGES="auv_nav_msg"
catkin_make -DCATKIN_WHITELIST_PACKAGES=""
cd $dir
end_time=$(date +%s)
cost_time=$[ $end_time-$start_time ]
echo "build time is $(($cost_time/60))min $(($cost_time%60))s"

