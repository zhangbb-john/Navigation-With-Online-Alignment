#include "au_localization/initial_usbl.h"

bool InitialUSBL::Initialization(vector<AngleMeasurement> &angle_measurements, vector<RecvimMeasurement> &recvim_measurements, Vector3d &beacon_pos, double *theta)
{
    if ((angle_measurements.size() + recvim_measurements.size() < 20) || (recvim_measurements.size() < 2) )
    {
        cout << "now angle_measurements size is " << angle_measurements.size() << endl << "recvim_measurements size is " << recvim_measurements.size() << endl;
        return false;
    }
    cout << "now angle_measurements size is " << angle_measurements.size() << endl << "recvim_measurements size is " << recvim_measurements.size() << endl;

    double beacon_pos_param[3] = {0, 0, 0}; // abc参数的估计值
    double theta_param[1] = {0};
    ceres::Problem problem;
    for (size_t i = 0; i < angle_measurements.size(); i++)
    {
        Vector2d angle = angle_measurements[i].angle;
        Vector2d sigma = angle_measurements[i].sigma;
        Vector3d position = angle_measurements[i].position;
        Quaterniond q = angle_measurements[i].q;
        problem.AddResidualBlock( // 向问题中添加误差项
                                  // 使用自动求导，模板参数：误差类型，输出维度，输入维度，维数要与前面struct中一致
            new ceres::AutoDiffCostFunction<ANGLE_COST, 2, 3, 1>(
                new ANGLE_COST(angle, sigma, position, q)),
            nullptr,          // 核函数，这里不使用，为空
            beacon_pos_param, // 待估计参数
            theta_param);
    }
    for (size_t i = 0; i < recvim_measurements.size(); i ++)
    {
        Vector2d recvim = recvim_measurements[i].recvim;
        Vector2d sigma = recvim_measurements[i].sigma;
        Vector3d position = recvim_measurements[i].position;
        Quaterniond q = recvim_measurements[i].q;
        Vector3d velocity = recvim_measurements[i].velocity;
        problem.AddResidualBlock( // 向问题中添加误差项
                                  // 使用自动求导，模板参数：误差类型，输出维度，输入维度，维数要与前面struct中一致
            new ceres::AutoDiffCostFunction<RECVIM_COST, 2, 3>(
                new RECVIM_COST(recvim, sigma, position, q, velocity)),
            nullptr,          // 核函数，这里不使用，为空
            beacon_pos_param // 待估计参数
            );        
    }
    // 配置求解器
    ceres::Solver::Options options;               // 这里有很多配置项可以填
    options.linear_solver_type = ceres::DENSE_QR; // 增量方程如何求解
    options.minimizer_progress_to_stdout = true;  // 输出到cout

    ceres::Solver::Summary summary; // 优化信息
    chrono::steady_clock::time_point t1 = chrono::steady_clock::now();
    ceres::Solve(options, &problem, &summary); // 开始优化

	if (summary.termination_type == ceres::CONVERGENCE && summary.final_cost < summary.initial_cost * 5.0e-3)
	{
        cout << "Initialization converge" << endl;
	}
	else
	{
        cout << "Initialization diverge " << endl;
        return false;
	}
    chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    chrono::duration<double> time_used = chrono::duration_cast<chrono::duration<double>>(t2 - t1);
    cout << "solve time cost = " << time_used.count() << " seconds. " << endl; 
    // 输出结果
    cout << summary.BriefReport() << endl;
    beacon_pos << beacon_pos_param[0], beacon_pos_param[1], beacon_pos_param[2];
    cout << "estimated beacon_pos = " << beacon_pos << endl;;

    *theta = theta_param[0]; 
    cout << "theta is " << theta_param[0] << endl;
    return true;
}
