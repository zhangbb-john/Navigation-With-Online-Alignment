clear
source ../../devel/setup.bash
roslaunch ./ukf_localization/launch/bag_localization.launch